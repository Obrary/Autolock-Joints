Product: Autolock Joints, October 2014

Designer: Emmanuel Patoux

Support:  http://forums.obrary.com/category/designs/autolock-joints

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
These pieces interlock on all sides.  With this design you can:
- combine/assemble it to obtain other shapes 
- copy/paste it to build big structures your laser bench cannot do